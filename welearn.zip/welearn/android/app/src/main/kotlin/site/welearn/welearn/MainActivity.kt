package site.welearn.welearn

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
